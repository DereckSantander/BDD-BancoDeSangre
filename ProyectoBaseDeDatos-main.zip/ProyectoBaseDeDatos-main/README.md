# ProyectoBaseDeDatos
Proyecto para la materia de Base de Datos.<br>
Cuenta con una interfaz gráfica que está conectada a una base de datos .sql<br>
El programa permite el registro de donaciones de sangre, tener control de los enfermeros y donadores registrados.<br>
